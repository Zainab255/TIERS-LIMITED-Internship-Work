import 'package:flutter/material.dart';

const Color tdRed = Color(0xFFDA4040);
const Color tdBlue = Color(0xFF7986CB);
const Color tdBlack = Color(0xFF212121);
const Color tdGrey = Color(0xFFBDBDBD);

const Color tdBGColor = Color(0xFFF5F5F5);

